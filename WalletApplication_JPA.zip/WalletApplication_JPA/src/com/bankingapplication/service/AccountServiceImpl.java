package com.bankingapplication.service;
import com.bankingapplication.exceptions.*;
import java.math.BigDecimal;
import com.bakapplication.AccountRepo.AccountRepo;
import com.bankapplication.beans.Customer;
import com.bankapplication.beans.Wallet;

public class AccountServiceImpl implements AccountService {

	AccountRepo accountrepoImpl;
	
	public AccountServiceImpl(AccountRepo accountRepo) {
	
		super();
		
		this.accountrepoImpl=accountRepo;
	}
	
	@Override
	public Customer createAccount(String phoneNumber,String name, Wallet wallet)throws NumberaAlreadyExistsException{
		
		Customer customer = new Customer();
		
		customer.setMobileNumber(phoneNumber);
		
		customer.setWallet(wallet);
		
		customer.setName(name);
		
		if(accountrepoImpl.save(customer))
		{
			return customer;
		}
		
		return null;
		
	}

	@Override
	public String Deposit(String accountNumber, BigDecimal amount) throws MobileNumberDoesNotExistException {
		
			Customer updatedCustomer = accountrepoImpl.searchAccount(accountNumber);
			
			updatedCustomer.getWallet().setBalance(updatedCustomer.getWallet().getBalance().add(amount));
			
			accountrepoImpl.updateCuostomer(updatedCustomer);
			
			return "Balance after Deposit: "+updatedCustomer.getWallet().getBalance();
			
	}

	@Override
	public String withdraw(String phoneNumber, BigDecimal amount) throws MobileNumberDoesNotExistException,InsufficientBalanceException {
	
		Customer updatedCustomer = accountrepoImpl.searchAccount(phoneNumber);
		
		updatedCustomer.getWallet().setBalance(updatedCustomer.getWallet().getBalance().subtract(amount));
		
		accountrepoImpl.updateCuostomer(updatedCustomer);
		
		return "Balance after Deposit: "+updatedCustomer.getWallet().getBalance();
		
		
	}

	public String fundsTransfer(String account1, String account2, BigDecimal amount) throws MobileNumberDoesNotExistException,InsufficientBalanceException {
		
		Customer customer1=accountrepoImpl.searchAccount(account1);
		
		Customer customer2=accountrepoImpl.searchAccount(account2);
		
		if(customer1.getWallet().getBalance().compareTo(amount)>=0){
			
			customer1.getWallet().setBalance(customer1.getWallet().getBalance().subtract(amount));
			
			withdraw(customer1.getMobileNumber(),amount);
			
			Deposit(customer2.getMobileNumber(),amount);
			
			return "Balance after deduction and transfer respectively: "+customer1.getWallet().getBalance()+" "+customer2.getWallet().getBalance();
		}
		
		return null;

	}

	@Override
	public Customer Show(String phoneNumber) throws MobileNumberDoesNotExistException {
		
		Customer account = accountrepoImpl.searchAccount(phoneNumber);
		
		return account;
	}
	
	@Override
	public void close() {
		
		accountrepoImpl.close();
		
	}

}