package com.bankapplication.clientside;
import java.math.BigDecimal;
import java.util.Scanner;

import com.bakapplication.AccountRepo.AccountRepo;
import com.bakapplication.AccountRepo.AccountRepoImpl;
import com.bankapplication.beans.Customer;
import com.bankapplication.beans.Wallet;
import com.bankingapplication.exceptions.InsufficientBalanceException;
import com.bankingapplication.exceptions.MobileNumberDoesNotExistException;
import com.bankingapplication.exceptions.NumberaAlreadyExistsException;
import com.bankingapplication.service.AccountService;
import com.bankingapplication.service.AccountServiceImpl;



public class ClientView {
	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {

		AccountRepo accountrepoimpl= new AccountRepoImpl();
		AccountService accountserviceimpl= new AccountServiceImpl(accountrepoimpl);
		
		int choice;
		
		while (true) {
			
			System.out.println("Enter your choice: ");
			System.out.println("1. Add wallet Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Withdraw from wallet Account");
			System.out.println("4. Deposit into Wallet Account");
			System.out.println("5. Transfer funds to another account");
			System.out.println("6. exit");
			choice= sc.nextInt();
			sc.nextLine();
			switch (choice) {
			
			case 1: System.out.println("Enter your mobile number: ");
					String mobile=sc.nextLine();
					verifyMobile(mobile);
					System.out.println("Enter your name: ");
					String name= sc.nextLine();
					System.out.println("Enter initial balance: ");
					BigDecimal balance= sc.nextBigDecimal();
					verifyNegativeBalance(balance);
						Wallet wallet=new Wallet();
						wallet.setBalance(balance);

					try {
						Customer customer=accountserviceimpl.createAccount(mobile,name,wallet);
						if(customer!=null)
							System.out.println(customer);
					} catch (NumberaAlreadyExistsException e1) {
						System.out.println(e1.getMessage());
					}		
					break;
					
					
			case 2: System.out.println("Enter your mobile number: ");
					String number= sc.nextLine();
					verifyMobile(number);
				try {
					Customer cst = accountserviceimpl.Show(number);
					System.out.println(cst);
					
					
				} catch (MobileNumberDoesNotExistException e) {
					System.out.println(e.getMessage());
				}
				break;
			
					
			
			case 3: System.out.println("Enter your mobile number: ");
					String phone= sc.nextLine();
					verifyMobile(phone);
						System.out.println("Enter the amount to withdraw: ");
							BigDecimal withdrawAmount= sc.nextBigDecimal();
					try {
						
						System.out.println(accountserviceimpl.withdraw(phone,withdrawAmount));
					}
					catch(MobileNumberDoesNotExistException ian) {
						
						System.out.println(ian.getMessage());
						
					} catch (InsufficientBalanceException e) {
						
						System.out.println(e.getMessage());
						
					}	
					break;
					
			case 4: System.out.println("Enter your mobile number: ");
					String mob= sc.nextLine();
					verifyMobile(mob);
					System.out.println("Enter the amount to deposit: ");
					BigDecimal amount= sc.nextBigDecimal();
					try {	
						System.out.println(accountserviceimpl.Deposit(mob,amount));
					}
					catch(MobileNumberDoesNotExistException ian) {
						System.out.println(ian.getMessage());
					}
					break;
					
			case 5: System.out.println("Enter the source mobile number");
					String source= sc.nextLine();
					verifyMobile(source);
					System.out.println("Enter the destination mobile number: ");
					String dest= sc.nextLine();
					verifyMobile(dest);
					System.out.println("Enter the amount to transfer: ");
					BigDecimal transferAmount= sc.nextBigDecimal();
					sc.nextLine();
					try {
						System.out.println(accountserviceimpl.fundsTransfer(source, dest,transferAmount));
					}
					catch(MobileNumberDoesNotExistException ian) {
						System.out.println(ian.getMessage());
					}
					catch(InsufficientBalanceException ib) {
						System.out.println(ib.getMessage());
					}
					break;
					
			case 6:
					accountserviceimpl.close();
					System.exit(0);
			
			}
			
			
		}
		
	}

	private static void verifyNegativeBalance(BigDecimal balance) {
		if(balance.compareTo(new BigDecimal(0))<0) {
			BigDecimal bal= sc.nextBigDecimal();
			verifyNegativeBalance(bal);
			
		}
		
	}
	

	private static boolean verifyMobile(String mobile) {
		if(!mobile.matches("[0-9]+")) {
			System.out.println("This is not a valid mobile number Please enter correct mobile number:");
			String mob=sc.nextLine();
			verifyMobile(mob);
		}
		if(mobile.length()==10)
			return true;
		else {
			System.out.print("Mobile number length is less that 10 Please enter correct mobile number: ");
			String mobi=sc.nextLine();
			verifyMobile(mobi);
			return true;
			}		
		
	}
	

}
