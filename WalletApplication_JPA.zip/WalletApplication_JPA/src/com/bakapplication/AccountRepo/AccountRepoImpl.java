package com.bakapplication.AccountRepo;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import com.bankapplication.beans.Customer;
import com.bankingapplication.exceptions.MobileNumberDoesNotExistException;
import com.bankingapplication.exceptions.NumberaAlreadyExistsException;

import jdbc_util.JDBC_Util;

public class AccountRepoImpl implements AccountRepo {
	
	private static EntityManager em;
	
	private static JDBC_Util util;
	

	public AccountRepoImpl() {
		
		util=JDBC_Util.getInstance();
		
		em= util.getEntityManager();
		
	}
	
	@Override
	public boolean save(Customer customer) throws NumberaAlreadyExistsException  {

		EntityTransaction transaction=em.getTransaction();
		
		transaction.begin();
		
		em.persist(customer);
		
		em.getTransaction().commit();
		
		return true;
		
	}

	@Override
	public Customer searchAccount(String phoneNumber) throws MobileNumberDoesNotExistException {
		
		Customer customer = em.find(Customer.class, phoneNumber);
		
		if(customer==null)
			throw new MobileNumberDoesNotExistException();
		
		else 			
			return customer;
		
	}

	@Override
	public Customer updateCuostomer(Customer updatedCustomer) throws MobileNumberDoesNotExistException {
		
		EntityTransaction transaction=em.getTransaction();
		
		transaction.begin();
		
		Customer cust = searchAccount(updatedCustomer.getMobileNumber());
		
		cust.getWallet().setBalance(updatedCustomer.getWallet().getBalance());
		
		em.getTransaction().commit();
		
		return cust;

	}

	@Override
	public void close() {
		
		em.close();
		
	}
	
}
