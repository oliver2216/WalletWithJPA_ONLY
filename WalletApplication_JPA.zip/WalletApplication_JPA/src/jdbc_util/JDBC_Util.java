package jdbc_util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JDBC_Util {
	
	private static JDBC_Util util= new JDBC_Util(); 
	private static EntityManagerFactory entitymanagerfactory= null;
	private static EntityManager entitymanager;
	
	private  JDBC_Util() {
		
		entitymanagerfactory= Persistence.createEntityManagerFactory("WalletApp_Link");
		entitymanager = entitymanagerfactory.createEntityManager();
		
	}
	public  EntityManager getEntityManager() {
		System.out.println("returning Entity Manager");
		return entitymanager;
		
	}
	
	public static JDBC_Util getInstance() {
		System.out.println("Returning util");
		return util;
	}
}
